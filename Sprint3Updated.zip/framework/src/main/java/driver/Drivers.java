package driver;


import org.openqa.selenium.remote.RemoteWebDriver;

public class Drivers {

	
	
	public static RemoteWebDriver driver;
	
}
