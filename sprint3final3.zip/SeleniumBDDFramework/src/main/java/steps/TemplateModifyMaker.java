package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.MakerTemplatePage;
import pages.OutwardTransactionDetailReport;
import pages.makerHomepage;
import pages.makersettings;

public class TemplateModifyMaker {
	
	makerHomepage makerhome = new makerHomepage();
	OutwardTransactionDetailReport outward = new OutwardTransactionDetailReport();
	makersettings makerset = new makersettings();
	MakerTemplatePage makertemp = new MakerTemplatePage();
	
	@When("^maker enter click edit button$")
    public void maker_enter_click_edit_button() throws Throwable {
		outward.waitforLoader();
		makertemp.edit_table();
    }
	
	@And("^maker clicks update button$")
    public void maker_clicks_update_button() throws Throwable {
    	makertemp.clickupdate();
    }
	
	 @Then("^template configuration updated successfully$")
	    public void template_configuration_updated_successfully() throws Throwable {
	    	outward.waitforLoader();
	    	makertemp.Verify_template_updated_toast_msg();
	    }

}
