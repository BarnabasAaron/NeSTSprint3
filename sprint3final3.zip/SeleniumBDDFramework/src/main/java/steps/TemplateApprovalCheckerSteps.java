package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pages.CheckerSettingsPage;
import pages.CheckerTemplatePage;
import pages.OutwardTransactionDetailReport;
import pages.checkerHomepage;


public class TemplateApprovalCheckerSteps {
	
	OutwardTransactionDetailReport outward = new OutwardTransactionDetailReport();
	checkerHomepage checkerhome = new checkerHomepage();
	CheckerTemplatePage checkertemplate = new CheckerTemplatePage();
	CheckerSettingsPage checkersettings = new CheckerSettingsPage();
	
	@And("^Checker clicks settings$")
    public void Checker_clicks_settings() throws Throwable {
		outward.waitforLoader();
		checkerhome.Click_Settings_btn();		
    }

    @Then("^Checker clicks template configuration approval$")
    public void Checker_clicks_template_configuration_approval() throws Throwable {
    	outward.waitforLoader();
    	checkersettings.click_tempconfig_btn();
    }

}
