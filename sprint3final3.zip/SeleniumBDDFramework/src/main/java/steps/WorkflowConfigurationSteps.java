package steps;

import org.openqa.selenium.ElementClickInterceptedException;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.CheckerAdminHomePage;
import pages.CheckerAdminSettingsPage;
import pages.MakerAdminSettings;
import pages.OutwardTransactionDetailReport;
import pages.WorkFlowRuleConfigurationApproval;
import pages.WorkFlowRuleConfigurationInitiation;
import pages.checkerHomepage;

public class WorkflowConfigurationSteps {
	
	
	MakerAdminSettings makerSettings = new MakerAdminSettings();
	WorkFlowRuleConfigurationInitiation config = new WorkFlowRuleConfigurationInitiation();
	OutwardTransactionDetailReport outward = new OutwardTransactionDetailReport();
	checkerHomepage checkerHome = new checkerHomepage();
	CheckerAdminHomePage checkerAdminHome = new CheckerAdminHomePage();
	CheckerAdminSettingsPage checkerAdminSettings = new CheckerAdminSettingsPage();
	WorkFlowRuleConfigurationApproval approve = new WorkFlowRuleConfigurationApproval();
	
	
	@And("^selects Workflow Rule Configuration in Settings$")
    public void selects_workflow_rule_configuration_in_settings() throws Throwable {
		outward.waitforLoader();
		makerSettings.clickWorkflowRuleConfiguration();
    }
	
	
	@When("^Maker selects Application$")
    public void maker_selects_application() throws Throwable {
		outward.waitforLoader();
		config.selectApplicationOption("NPSS");
    }

    @And("^Maker selects Message Type$")
    public void maker_selects_message_type() throws Throwable {
    	
    	config.selectMessageType("Realtime");
    }

    @And("^Maker selects Event Type$")
    public void maker_selects_event_type() throws Throwable {
    	outward.waitforLoader();
    	config.selectEventType("Outward Flow");
    }
    
    

    @And("^Maker Enters Rule Name$")
    public void maker_enters_rule_name() throws Throwable {
    	outward.waitforLoader();
    	config.enterRuleName("UnblockPosting14");
    	
    }

    @And("^maker selects Field$")
    public void maker_selects_field() throws Throwable {
    	config.selectFieldOptionsFirstRow("TransactionType");
    }

    @And("^Maker selects Operator$")
    public void maker_selects_operator() throws Throwable {
    	outward.waitforLoader();
    	config.selectOperatorOptionsFirstRow("Equal to");
    }

    @And("^Maker selects Value$")
    public void maker_selects_value() throws Throwable {
    	
    	config.selectValueOptionsFirstRow("ACM");
    }
    
    @And("^selects add button to add new clause$")
    public void selects_add_button_to_add_new_clause() throws Throwable {
    	
    	config.clickAddNewClause();
    
    }

    @And("^selects and operator$")
    public void selects_and_operator() throws Throwable {
    	outward.waitforLoader();
    	config.selectAndORFieldFirst("AND");
        
    }

    @And("^maker selects Amount in new clause$")
    public void maker_selects_amount_in_new_clause() throws Throwable {
    	
    	config.selectFieldOptionsSecondRow("Amount");
        
    }

    @And("^maker selects Operator in new clause$")
    public void maker_selects_operator_in_new_clause() throws Throwable {
    	outward.waitforLoader();
    	config.selectOperatorOptionsSecondRow("Equal to");
        
    }

    @And("^maker selects value in new clause$")
    public void maker_selects_value_in_new_clause() throws Throwable {
    	
    	config.selectValueOptionsSecondRow("15");
    	outward.waitforLoader();
        
    }
    
    @And("^selects is STP$")
    public void selects_is_stp() throws Throwable {
        
    	config.clickIsSTPCheckbox();
    }

    @And("^selects Stp status$")
    public void selects_stp_status() throws Throwable {
    
    	
        try {
			config.selectStpStatus("STP");
		} catch (ElementClickInterceptedException e) {
			// Getting sometimes intercepted with loader so added to wait for loader
			outward.waitforLoader();
			config.selectStpStatus("STP");
			
		}
    }

    @And("^enters Sort Order$")
    public void enters_sort_order() throws Throwable {
        config.enterSortOrder("1");
    }

    @And("^selects submit$")
    public void selects_submit() throws Throwable {
        config.selectSubmitButton();
    }

    @And("^verifies data in table$")
    public void verifies_data_in_table() throws Throwable {
    	outward.waitforLoader();
        config.verifyDataInTable("UnblockPosting14");
    }

    @And("^Checker selects the option to change Admin$")
    public void checker_selects_the_option_to_change_admin() throws Throwable {
        outward.waitforLoader();
    	checkerHome.selectOptionToChangeAccess();
    	
    }

//    @And("^selects settings from side menu$")
//    public void selects_settings_from_side_menu() throws Throwable {
//    	outward.waitforLoader();
//    	checkerAdminHome.selectSettings();
//    }

    @And("^selects Workflow Rule Configuration Approval in Seetings$")
    public void selects_workflow_rule_configuration_approval_in_seetings() throws Throwable {
        outward.waitforLoader();
        checkerAdminSettings.clickWorkflowRuleApproval();
    }

    @And("^selects edit icon for the particular transaction$")
    public void selects_edit_icon_for_the_particular_transaction() throws Throwable {
        outward.waitforLoader();
        approve.selectEditIconofTable();
    }

    @And("^verifiies the data$")
    public void verifies_the_data() throws Throwable {
        outward.waitforLoader();
        approve.verifyApplication();
        approve.verifyEventType();
        approve.verifyRuleName();
    }

    @And("^selects Approve$")
    public void selects_approve() throws Throwable {
        approve.clickApprove();
    }

    @And("^selects Reject$")
    public void selects_reject() throws Throwable {
    	
        approve.clickReject("Test tests");
    }


}
