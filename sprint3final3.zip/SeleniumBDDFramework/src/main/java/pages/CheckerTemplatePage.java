package pages;

import org.openqa.selenium.support.PageFactory;

import baseClass.baseClass;
import driver.Drivers;

public class CheckerTemplatePage extends Drivers {
	
	static baseClass base = new baseClass();

	public CheckerTemplatePage() {

		PageFactory.initElements(driver, this);
	}
	
	

}
