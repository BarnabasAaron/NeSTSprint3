package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import baseClass.baseClass;
import driver.Drivers;


public class RealtimePaymentReversalInitiationPage extends Drivers {
	
static baseClass base = new baseClass();

	
	public RealtimePaymentReversalInitiationPage() {
		
		PageFactory.initElements(driver,this);
	}
	
	
	@FindBy(xpath = "(//mat-icon[.='edit '])[1]")
	public WebElement Editicon;
	
	@FindBy(xpath = "//span[contains(text(),'Approve')]")
	public WebElement Approve_btn;
	
	@FindBy(xpath = "//span[contains(text(),'Reject')]")
	public WebElement Reject_btn;
	
	@FindBy(xpath = "//div[contains(text(),'History')]")
	public WebElement History_btn;
	
	@FindBy(xpath = "//mat-error[contains(text(),' Remarks is mandatory for Reject')]")
	public WebElement Reject_error;
	
	@FindBy(xpath = "(//span[.='Approve'])[2]")
	public WebElement ApprovePopup_btn;
	
	@FindBy(xpath = "(//span[.='Reject'])[2]")
	public WebElement RejectPopup_btn;
	
	@FindBy(xpath = "//div[contains(text(),'Settled Amount:')]/following::input[1]")
	public WebElement RemarksPopup_approve;
	
	@FindBy(xpath = "//div[contains(text(),'Settled Amount:')]/following::input[1]")
	public WebElement RemarksPopup_reject;
	
	@FindBy(xpath = "//h3[contains(text(),'Payment Reversal Checker History')]")
	public WebElement History_page;
	
	@FindBy(xpath = "//div[contains(text(),'Settled Amount:')]/following::input[1]")
	public WebElement RemarksPopup_approve_history;
	
	@FindBy(xpath = "//div[contains(text(),'Settled Amount:')]/following::input[1]")
	public WebElement RemarksPopup_reject_history;
	
	@FindBy(xpath = "//mat-select[@role='combobox']")
	public WebElement reasonelemnt;
	
	@FindBy(xpath = "//span[contains(text(),'TM01 - Associated message was received after agree')]")
	public WebElement reason_dropdown;
	
	@FindBy(xpath = "//span[contains(text(),'Confirm Reversal Initiation')]")
	public WebElement confirm_btn;
	
	@FindBy(xpath="//div[.='Reversal Payment Initiated Successfully!']")
	public WebElement success_toast;
	
	@FindBy(xpath = "//mat-error[contains(text(),' Reversal Reason is required ')]")
	public WebElement reason_error;
	
	public void view_error() {
		base.highLighterMethod(reason_error);
		base.explicitWait(reason_error);
		boolean actual= reason_error.isDisplayed();
		Assert.assertEquals(actual, true);
	}
	
	public void view_toast() {
		base.highLighterMethod(success_toast);
		base.explicitWait(success_toast);
		boolean actual= success_toast.isDisplayed();
		Assert.assertEquals(actual, true);
	}
	
	public void click_confirm_btn() {
		base.highLighterMethod(confirm_btn);
		base.explicitWait(confirm_btn);
		base.click(confirm_btn);
	}
	
	public void select_reason() throws InterruptedException {
		
		base.scrollToElement(reasonelemnt);
		base.highLighterMethod(reasonelemnt);
//		base.click(reasonelemnt);
		
//		base.highLighterMethod(reason_dropdown);
//		base.explicitWait(reason_dropdown);
//		base.click(reason_dropdown);
	}
	
	public void Click_Editicon_btn() throws InterruptedException {
		base.explicitWait(Editicon);

		base.highLighterMethod(Editicon);
		base.explicitWait(Editicon);
		base.click(Editicon);
	}
	
	public void click_Approve_btn() throws InterruptedException {
		base.explicitWait(Approve_btn);
		base.highLighterMethod(Approve_btn);
		base.explicitWait(Approve_btn);
		base.click(Approve_btn);
	}

	
	public void click_reject_btn() throws InterruptedException {
		base.explicitWait(Reject_btn);
		base.highLighterMethod(Reject_btn);
		base.explicitWait(Reject_btn);
		base.click(Reject_btn);
	}
	
	public void Click_ApprovePopup() throws InterruptedException {
		base.explicitWait(ApprovePopup_btn);
		base.highLighterMethod(ApprovePopup_btn);
//		base.click(ApprovePopup_btn);
		
	}
	
	public void Click_RejectPopup() throws InterruptedException {
		base.explicitWait(RejectPopup_btn);
		base.highLighterMethod(RejectPopup_btn);
//		base.click(RejectPopup_btn);
	}
	
	public void Approve_RemarksPopup() throws InterruptedException {

		base.explicitWait(RemarksPopup_approve);
		String remarks = System.getProperty("Remarks");
		base.highLighterMethod(RemarksPopup_approve);
		base.sendKeys(RemarksPopup_approve, remarks);
		base.explicitWait(RemarksPopup_approve);
//		base.click(RemarksPopup_approve);
	}
	
	public void Reject_RemarksPopup() throws InterruptedException {

		base.explicitWait(RemarksPopup_reject);
		String remarks = System.getProperty("Remarks");
		base.highLighterMethod(RemarksPopup_reject);
		base.sendKeys(RemarksPopup_reject, remarks);
		base.explicitWait(RemarksPopup_reject);
//		base.click(RemarksPopup_reject);
	}
	
	public void Click_History_btn() throws InterruptedException {
		base.explicitWait(History_btn);
		base.highLighterMethod(History_btn);
		base.click(History_btn);
		
	}
	
	public void View_History_page() throws InterruptedException {
		base.explicitWait(History_page);
		base.highLighterMethod(History_page);
		base.explicitWait(History_page);
		Assert.assertEquals(base.isDisplayed(History_page), true);
	}
	
	
	public void Approve_History_RemarksPopup() throws InterruptedException {
		base.explicitWait(RemarksPopup_approve_history);
		base.highLighterMethod(RemarksPopup_approve_history);
		String remarks = System.getProperty("Remarks");
		base.sendKeys(RemarksPopup_approve_history, remarks);
		base.explicitWait(RemarksPopup_approve_history);
		base.click(RemarksPopup_approve_history);
	}
	
	public void Reject_History_RemarksPopup() throws InterruptedException {
		base.explicitWait(RemarksPopup_reject_history);
		base.highLighterMethod(RemarksPopup_reject_history);
		String remarks = System.getProperty("Remarks");
		base.sendKeys(RemarksPopup_reject_history, remarks);
		base.explicitWait(RemarksPopup_reject_history);
		base.click(RemarksPopup_reject_history);
	}
	
	public void Reject_withoutentering_remarks() throws InterruptedException {
		base.explicitWait(Reject_error);
		base.highLighterMethod(Reject_error);
		base.explicitWait(Reject_error);
		Assert.assertEquals(base.isDisplayed(Reject_error), true);
	}
	

}
